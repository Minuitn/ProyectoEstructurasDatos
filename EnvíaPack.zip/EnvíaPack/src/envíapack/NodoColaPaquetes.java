package envíapack;

/**
 *
 * @author melic
 */
public class NodoColaPaquetes {
    
    private Paquete dato;
    private NodoColaPaquetes siguiente;

    public NodoColaPaquetes() {
        this.siguiente = null;
    }

    public Paquete getDato() {
        return dato;
    }

    public void setDato(Paquete dato) {
        this.dato = dato;
    }

    public NodoColaPaquetes getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoColaPaquetes siguiente) {
        this.siguiente = siguiente;
    }
    
    
}
