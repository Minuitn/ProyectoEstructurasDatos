package envíapack;

/**
 *
 * @author melic
 */
public class NodoListaPaquetes {
    
    //Se podría usar solo uno para la lista, pila, cola 
    //por que sus nodos son iguales. Por ahora se mantendra así.
    
    private Paquete dato;
    private NodoListaPaquetes siguiente;

    public NodoListaPaquetes(Paquete dato) {
        this.dato = dato;
    }

    public Paquete getDato() {
        return dato;
    }

    public void setDato(Paquete dato) {
        this.dato = dato;
    }

    public NodoListaPaquetes getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoListaPaquetes siguiente) {
        this.siguiente = siguiente;
    }
    
    
    
}
