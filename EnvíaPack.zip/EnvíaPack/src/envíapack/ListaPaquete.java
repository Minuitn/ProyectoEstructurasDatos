package envíapack;

/**
 *
 * @author melic
 */
public class ListaPaquete {
    
}
