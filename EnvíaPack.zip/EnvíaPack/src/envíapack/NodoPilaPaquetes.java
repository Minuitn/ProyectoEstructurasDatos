package envíapack;

/**
 *
 * @author melic
 */
public class NodoPilaPaquetes {
    
    private Paquete dato;
    private NodoPilaPaquetes siguiente;

    public NodoPilaPaquetes() {
        this.siguiente = null;
    }

    public Paquete getDato() {
        return dato;
    }

    public void setDato(Paquete dato) {
        this.dato = dato;
    }

    public NodoPilaPaquetes getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoPilaPaquetes siguiente) {
        this.siguiente = siguiente;
    }
    
    
    
    
}
